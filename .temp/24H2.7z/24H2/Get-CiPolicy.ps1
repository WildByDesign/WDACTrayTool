$DesktopPath = [Environment]::GetFolderPath('Desktop')
$FileSave = $DesktopPath + '\output-original.txt'
(C:\Windows\System32\CiTool.exe -lp -json | ConvertFrom-Json).Policies | Select-Object -Property FriendlyName,PolicyID,IsSignedPolicy | FT | Out-File -FilePath $FileSave

$DesktopPath = [Environment]::GetFolderPath('Desktop')
$FileSave = $DesktopPath + '\output-24H2.txt'
(.\CiTool.exe -lp -json | ConvertFrom-Json).Policies | Select-Object -Property FriendlyName,PolicyID,IsSignedPolicy | FT | Out-File -FilePath $FileSave
